package com.nawres.androidteste.globale;

public class Constant {
    public final static long Splash_Screen=2000;
    public static  final String MY_PREF="my prefers";
    public static  final String KEY_NAME="name";
    public static  final String PREF_IS_CONNECT="is connected";

}
